"use strict"

const path = require("path")
const express = require("express")
const cors = require("cors")
const { processBfhl, buildUserId } = require("./bfhl")

const app = express()
const PORT = process.env.PORT || 3000

// Middleware
app.use(cors())
app.use(express.json({ limit: "1mb" }))
app.use(express.static(path.join(__dirname, "public")))

// --- API ROUTES ---------------------------------------------------------

// POST /bfhl -> main endpoint required by the test
app.post("/bfhl", (req, res) => {
  try {
    const result = processBfhl(req.body)
    return res.status(200).json(result)
  } catch (err) {
    return res.status(err.statusCode || 500).json({
      is_success: false,
      user_id: buildUserId(),
      error: err.message || "Internal Server Error",
    })
  }
})

// GET /bfhl -> the spec specifies it should return the operation code 200
app.get("/bfhl", (_req, res) => {
  return res.status(200).json({ operation_code: 1 })
})

// Simple health check
app.get("/health", (_req, res) => res.status(200).json({ status: "ok" }))

// --- FRONTEND -----------------------------------------------------------

// Serve the single-page frontend for the root route
app.get("/", (_req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"))
})

// 404 fallback for unknown API paths
app.use((req, res) => {
  if (req.path.startsWith("/bfhl") || req.path.startsWith("/api")) {
    return res.status(404).json({ is_success: false, error: "Not Found" })
  }
  res.sendFile(path.join(__dirname, "public", "index.html"))
})

app.listen(PORT, () => {
  console.log(`[v0] BFHL server running on http://localhost:${PORT}`)
  console.log(`[v0] POST /bfhl  |  GET /bfhl  |  frontend at /`)
})

module.exports = app
